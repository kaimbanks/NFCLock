//
//  ViewController.swift
//  NFC-Lock
//
//  Created by Nikki Wines on 3/24/18.
//  Copyright © 2018 Nikki Wines. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBOutlet weak var particleEmail: UITextField!
    @IBOutlet weak var particlePassword: UITextField!
    
    
    @IBAction func particleLogin(_ sender: UIButton) {
        let email = particleEmail.text
        let password = particlePassword.text
        
        SparkCloud.sharedInstance().login(withUser: email!, password: password!) { (error:Error?) -> Void in
            if (email == "") || (password == "") {
                print("Please enter both username and password")
            }
            else if let _ = error {
                print("Wrong credentials or no internet connectivity, please try again")
                
            }
            else {
                print("Logged in")
                self.performSegue();
            }
        }
    }
    
    func performSegue() {
        performSegue(withIdentifier: "status segue", sender: self)
    }
    
}



