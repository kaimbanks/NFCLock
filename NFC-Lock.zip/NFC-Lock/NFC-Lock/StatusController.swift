//
//  StatusController.swift
//  NFC-Lock
//
//  Created by Nikki Wines on 3/25/18.
//  Copyright © 2018 Nikki Wines. All rights reserved.
//

import Foundation
import UIKit

class StatusController: UIViewController {
    
    var photon : SparkDevice?
    var lockStatus : String = "unlocked"
    @IBOutlet weak var toggleValue: UISwitch!
    @IBOutlet weak var doorStatusLabel: UILabel?
    @IBOutlet weak var deviceNameLabel: UILabel!
    @IBOutlet weak var userEmailLabel: UILabel!
    @IBOutlet weak var doorToggle: UISwitch!
    @IBOutlet weak var popupHorizontalConstraint: NSLayoutConstraint!
    @IBOutlet weak var popupVerticalConstraint: NSLayoutConstraint!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadDevice();
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func loadDevice() {
        SparkCloud.sharedInstance().getDevices { (devices:[SparkDevice]?, error:Error?) -> Void in
            if let _ = error {
                print("Check your internet connectivity")
            }
            else {
                if let d = devices {
                    for device in d{
                        if device.name == "square-doctor" {
                            self.photon = device
                            self.deviceNameLabel.text = device.name
                            self.userEmailLabel.text = SparkCloud.sharedInstance().loggedInUsername
                            self.checkDoorStatus()
                        }
                    }
                }
            }
        }
    }
    
    func checkDoorStatus() {
        print("getting status")
        self.photon!.getVariable("lockStatus", completion: { (result:Any?, error:Error?) -> Void in
            if let _ = error {
                print("Failed reading doorstatus from device")
            }
            else {
                if let status = result as? String {
                    self.lockStatus = status
                    print(status)
                    self.doorToggle.isOn = self.lockStatus == "locked"
                    
                    if self.doorToggle.isOn {
                        self.doorStatusLabel?.text = "Locked"
                        self.doorStatusLabel?.textColor = UIColor.green
                    }
                    else {
                        self.doorStatusLabel?.text = "Unlocked"
                        self.doorStatusLabel?.textColor = UIColor.red
                    }
                }
            }
        })
    }
    
    @IBAction func toggleDoorStatus(_ sender: UISwitch) {
        
        let funcArgs = ["Door1"]
        let _ = photon!.callFunction("toggleLock", withArguments: funcArgs) { (resultCode : NSNumber?, error : Error?) -> Void in
            if (error == nil) {
                print("Door succesfully toggled")
            }
        }
        
//        let b = task.countOfBytesExpectedToReceive
//        print(b)
    
        
        checkDoorStatus()
    }
    


    
    @IBAction func settingsClicked(_ sender: UIButton) {
        popupHorizontalConstraint.constant = 109
        popupVerticalConstraint.constant = 0
        
        UIView.animate(withDuration: 0.3, animations: {
            self.view.layoutIfNeeded()
            })
        
    }
    
    @IBAction func settingsClose(_ sender: Any) {
        popupHorizontalConstraint.constant = 400
        popupVerticalConstraint.constant = -300
        
        UIView.animate(withDuration: 0.3, animations: {
            self.view.layoutIfNeeded()
        })
    }
    
    @IBAction func logout(_sender: UIButton) {
        SparkCloud.sharedInstance().logout()
        performSegue(withIdentifier: "logout segue", sender: self)
        print("Logged Out")
    }
}
